public class Grandfather {
   private String name;
   private int age;

   public String getName() {
      return name;
   }

   public int getAge() {
      return age;
   }
}
