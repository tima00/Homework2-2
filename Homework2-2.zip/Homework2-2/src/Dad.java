public class Dad extends Grandfather{
  private String name;
  private int age;

  final void makeVoice(){
    System.out.println("Сделай уроки");

  }

  void makeVoice(String voice){
    System.out.println(voice);
  }

  @Override
  public String getName() {
    return name;
  }

  @Override
  public int getAge() {
    return age;
  }
}
