public enum Profession{;
    private String name;
    private String address;


    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    Profession(String name, String address){
        this.name = name;
        this.address = address;

    }


}
